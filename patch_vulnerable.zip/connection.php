<?php
    $dbuser = "root";
    $dbpass = "toor";
    $dbname = "secure_coding";
    $host = "localhost";
    error_reporting(0);
    //$connection = mysqli_connect($host, $dbuser, $dbpass, $dbname) or die("Connection Failed: ".mysqli_connect_errno());
    //$conn = new PDO(mysql:$host, $dbuser, $dbpass, $dbname);
    $conn = new PDO('mysql:host=localhost;dbname=secure_coding',$dbuser,$dbpass)
?>
