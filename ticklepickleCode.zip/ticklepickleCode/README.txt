Read Me
-----------

a. pwn_pickle.py - For showing deserialization in action
b. secure_client.py - changed client.py file - more secure now
c. secure_server.py - changed server.py file - more secure now
d. If you already have the old users.json do an rm and then for secure code a new users.json should be created
e. Strictly compatible with python3.6