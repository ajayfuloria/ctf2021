import os
import pickle
import hashlib
def fun(name,password):
    s = {"username":name,"password":password}
    safecode = pickle.dumps(s)
    hi = hashlib.sha256() #new('sha512_256')
    hi.update((safecode))
    hi.hexdigest()
    print(hi.hexdigest())
    #print(safecode)
    with open("users.json","wb") as f:
        f.write(safecode)
    return safecode

if __name__ == '__main__':
    u = input("Username : ")
    p = input("Password : ")
    fun(u,p)
    
    #yo_fun = fun(u,p)
