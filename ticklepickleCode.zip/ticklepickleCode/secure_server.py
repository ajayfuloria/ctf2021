import os
import pickle
import hashlib

hash="ae65c13aea8fdfcf84430a51c36d448caa70df8ecb543dace769a4f580e00282" # for user=ajay and password= ajay
def newFunc():
      with open("users.json","rb") as f:
          data = f.read()
      hi = hashlib.sha256()
      hi.update((data))
      hi.hexdigest()
      print(hi.hexdigest())
      if (hash==hi.hexdigest()):
      	   print("match")
      	   d = pickle.loads(data)
      	   return d
      else:
           return("mismatch")

if __name__ == '__main__':
      print(newFunc())